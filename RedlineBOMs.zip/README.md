# Redline de BOMs — Herramienta de marcado de cambios

Procesa en lote PDFs de BOM (Oracle EBS "Bill of Material Structure Report") y
genera dos versiones de cada uno según un Excel de instrucciones:

- **`..._REDLINE.pdf`** — cambios marcados: lo eliminado tachado, lo agregado en rojo.
- **`..._CLEAN_COPY.pdf`** — cambios ya aplicados, todo en negro.

Nombre de salida: `item(BOM)_REVxxx_REDLINE.pdf`
p. ej. `4D-81-584Z-G(BOM-005379)_REV001_REDLINE.pdf`

---

## Contenido

| Archivo | Qué es |
|---|---|
| `bom_ui.py` | **La aplicación** (interfaz de escritorio) |
| `bom_runner.py` | El motor: procesa una carpeta completa |
| `bom_excel.py` | Lector del Excel de instrucciones |
| `bom_engine.py` | Las operaciones de redline |
| `bom_layout.py` | Detección y validación del formato del PDF |
| `probar_un_bom.py` | Script para probar un solo PDF |
| `diagnostico.py` | Reporta la estructura de un PDF que falla (sin exponer su contenido) |
| `plantilla_cambios.xlsx` | Plantilla del Excel de instrucciones |

---

## Uso

1. Abre la aplicación (`RedlineBOMs.exe`, o `python bom_ui.py`).
2. Elige la **carpeta con los PDFs**, el **Excel** de cambios y la **carpeta de salida**.
3. Clic en **Procesar**.

---

## El Excel de instrucciones

Cuatro hojas, todas cruzadas con los PDFs por `nombre_archivo` (basta con que el
nombre del archivo lo contenga).

### `Config` — una fila por BOM
| Columna | Para qué |
|---|---|
| `nombre_archivo` | Nombre del PDF (sin extensión) |
| `codigo_bom` | Código del BOM (ej. `BOM-005379`) |
| `agregar_bom` | `SI` / `NO` — agregar el BOM al inicio |
| `actualizar_revision` | `SI` / `NO` — subir la revisión general |
| `pagina_horizontal` | `SI` / `NO` — convertir las páginas a apaisado |
| `revision_misma_linea` | `SI` / `NO` — poner la revisión junto a su etiqueta |
| `rev_bom` | Revisión del BOM (número). Vacío = `001` |
| `rev_description` | Texto para la columna 'Rev Description' de la fila del BOM |

### `Reemplazos` — cambiar el código de un componente
`nombre_archivo | componente_actual | componente_nuevo`

### `Inserciones` — agregar componentes al final
`nombre_archivo | item | descripcion | cantidad | uom | rev | level | op_seq |
item_seq | item_status | item_category`

Solo `item` y `descripcion` son obligatorios.

### `Ediciones` — editar un campo de un componente existente
`nombre_archivo | item | campo | valor_nuevo`

`campo` admite: `cantidad`, `rev`, `uom`, `descripcion`, `item_status`,
`item_category`, `level`, `op_seq`, `item_seq`, `rev_description`.

> **Revisión automática:** si `campo` es `rev` y dejas `valor_nuevo` vacío, se lee
> la revisión actual y se avanza en el abecedario (`A`→`B`, `Z`→`AA`).

---

## Las dos revisiones

- **Revisión general** del documento (header `Revision:`) → **letras**: `A`→`B`→`C`.
  Si viene numérica (`001`), pasa a `A`.
- **Revisión del BOM** (columna `Rev` de su fila) → **números de 3 dígitos**: `009`.

Al agregar el BOM hay dos casos:
- **No está en la lista** → se inserta la fila (secuencias en `1`, cantidad `0.00`).
- **Ya está** → no se inserta; se **actualiza su `Rev`** (el de `rev_bom`, o +1).

---

## 'Rev Description' y la orientación de la página

Oracle coloca estas columnas en un sitio distinto según el ancho del reporte, y
el programa lo detecta solo:

- **Hoja vertical (angosta):** el encabezado no cabe y hace *wrap* — `Rev
  Description` se envuelve a un segundo renglón de guiones, así que sus valores
  se escriben en el **renglón siguiente** de cada fila.
- **Hoja horizontal (ancha):** todo cabe en una línea (12 columnas) — `Rev
  Description` queda a la derecha de `Item Category` y sus valores van en la
  **misma línea** de la fila.

---

## Instalación y empaquetado

```
pip install pymupdf openpyxl
python bom_ui.py
```

Para generar el ejecutable:

```
pip install pyinstaller
pyinstaller --windowed --name "RedlineBOMs" bom_ui.py
```

Genera `dist\RedlineBOMs\` con el `.exe` dentro; para distribuir, comprime esa
carpeta. No uses `--onefile`: arranca mucho más lento.

---

## Notas

- **Formatos soportados:** Inventory (10 columnas) y Engineering (14 columnas). El
  layout se detecta solo; si un PDF no encaja, se aborta ese archivo con aviso.
  Funciona también con reportes horizontales y con la tabla en páginas posteriores.
- **Seguridad:** si una inserción empujaría contenido fuera de la página, se aborta
  con mensaje en vez de perder datos.
- Las operaciones se limitan a la sección del BOM (hasta el primer "End of Report").
- Si un PDF falla, corre `diagnostico.py` sobre él: reporta la estructura sin
  mostrar el contenido del documento.
- **No trabajes dentro de OneDrive:** puede bloquear o revertir los archivos y da
  errores al empaquetar. Usa una carpeta local (p. ej. `C:\BOM`).

---

## Pendientes conocidos

- Número de CR en la descripción.
- Soporte para Routing Reports (requiere OCR: su texto no es extraíble).
- Reflujo de página cuando una inserción no cabe.
- Con *wrap*, la 'Rev Description' de un componente puede solaparse con la fila
  siguiente si ese componente no tiene descripción de varias líneas.
