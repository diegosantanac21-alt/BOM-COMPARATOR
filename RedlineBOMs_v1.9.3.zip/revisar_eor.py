"""
revisar_eor.py — Diagnóstico del error "no se encontró End of Report".

Dice tres cosas:
  1. QUÉ bom_layout.py se está usando de verdad (ruta y versión). Si la versión
     no es 1.8.1 o mayor, el archivo no se reemplazó y ese es el problema.
  2. Si cada PDF tiene 'End of Report', en qué página, y cómo viene escrito.
  3. Las últimas líneas del documento, ENMASCARADAS (letras -> X, números -> 9),
     para poder comparar el formato sin exponer el contenido del documento.

Uso:
    python revisar_eor.py              (revisa la carpeta "entrada")
    python revisar_eor.py mi_carpeta
"""

import os
import re
import sys

import fitz

CARPETA_POR_DEFECTO = "entrada"
EOR_RE = re.compile(r"end\s*[-_]?\s*of\s*[-_]?\s*report", re.I)


def enmascarar(texto):
    """Oculta el contenido: letras -> X, dígitos -> 9. Deja símbolos y espacios."""
    out = []
    for ch in texto:
        if ch.isdigit():
            out.append("9")
        elif ch.isalpha():
            out.append("X")
        else:
            out.append(ch)
    return "".join(out)


def lineas_de(page):
    """[(y, texto_de_la_linea, n_spans)] uniendo los spans de cada renglón."""
    out = []
    for b in page.get_text("dict")["blocks"]:
        if b["type"] != 0:
            continue
        for ln in b["lines"]:
            txt = "".join(s["text"] for s in ln["spans"])
            if txt.strip():
                out.append((ln["bbox"][1], txt, len(ln["spans"])))
    return sorted(out)


def revisar(ruta):
    print("\n" + "-" * 60)
    print(os.path.basename(ruta))
    doc = fitz.open(ruta)
    print(f"  páginas: {len(doc)} | rotación pág.1: {doc[0].rotation}")

    encontrado = None
    for pn in range(len(doc)):
        for y, txt, n in lineas_de(doc[pn]):
            if EOR_RE.search(txt):
                encontrado = (pn, y, txt, n)
                break
        if encontrado:
            break

    if encontrado:
        pn, y, txt, n = encontrado
        print(f"  End of Report: SÍ · página {pn + 1} · y={y:.1f} · "
              f"partido en {n} span(s)")
        print(f"     tal cual: {txt.strip()!r}")
    else:
        print("  End of Report: NO aparece en ninguna página.")
        ult = doc[len(doc) - 1]
        print("     últimas líneas del documento (enmascaradas):")
        for y, txt, n in lineas_de(ult)[-5:]:
            print(f"       y={y:7.1f} | {enmascarar(txt.strip())[:70]}")

    # ¿Qué dice el motor?
    try:
        from bom_layout import detect_layout, validate_layout
        lay = detect_layout(doc)
        ok, msg = validate_layout(doc, lay)
        print(f"  validate_layout: {'OK' if ok else 'FALLA'} -> {msg}")
        if lay.get("ok"):
            print(f"     eor_page={lay['eor_page']} eor_y={lay['eor_y']} "
                  f"estimado={lay.get('eor_estimado')}")
    except Exception as e:
        print(f"  no se pudo evaluar con bom_layout: {e}")

    doc.close()


def main():
    carpeta = sys.argv[1] if len(sys.argv) > 1 else CARPETA_POR_DEFECTO

    print("=" * 60)
    try:
        import bom_layout
        print(f"bom_layout EN USO : {os.path.abspath(bom_layout.__file__)}")
        print(f"versión           : {bom_layout.__version__} ({bom_layout.__fecha__})")
        if bom_layout.__version__ < "1.8.1":
            print("  *** ESTA ES LA CAUSA: el archivo no se reemplazó. ***")
            print("  Copia el bom_layout.py nuevo encima y vuelve a correr.")
    except Exception as e:
        print("No se pudo importar bom_layout:", e)
    print("=" * 60)

    if not os.path.isdir(carpeta):
        print(f"No existe la carpeta '{carpeta}'.")
        return
    pdfs = [os.path.join(carpeta, n) for n in sorted(os.listdir(carpeta))
            if n.lower().endswith(".pdf")]
    if not pdfs:
        print(f"No hay PDFs en '{carpeta}'.")
        return
    for r in pdfs:
        revisar(r)


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    main()
