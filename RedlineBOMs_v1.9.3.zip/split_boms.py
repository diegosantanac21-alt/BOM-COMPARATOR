"""
split_boms.py — Separa un reporte consolidado de BOMs (Oracle EBS "Bill of
Material Structure Report") en un PDF por cada BOM.

Cada PDF de salida lleva:
  - La PORTADA del reporte (con el bloque de parámetros completo, que el
    encabezado de cada BOM no trae).
  - El contenido del BOM, desde su línea 'Organization:' hasta justo antes del
    siguiente BOM (el último, hasta el 'End of Report').
  - Un 'End of Report' al final.

Uso:
    1. Pon los reportes consolidados en la carpeta de entrada.
    2. Ajusta las rutas abajo si hace falta.
    3. python split_boms.py

Requiere:  pip install pymupdf openpyxl
"""

import os
import re
import sys
from pathlib import Path

try:
    import fitz
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
except ImportError as exc:
    print(f"Falta una dependencia: {exc}")
    print("Ejecuta: pip install pymupdf openpyxl")
    raise SystemExit(1)

__version__ = "1.5.0"
__fecha__ = "2026-10-13"

# ── Historial ───────────────────────────────────────────────────────────────
# 1.5.0  Los saltos de página ya no parten renglones ni separan el encabezado
#        de su tabla. Antes el corte se hacía a ras del espacio disponible, así
#        que en los reportes apaisados (encabezado de dos renglones: 'Op Item'
#        arriba y 'Seq Seq' debajo) una página terminaba con 'Item' y la
#        siguiente empezaba con 'Seq'. Ahora se corta siempre al INICIO de un
#        renglón y, si ese punto parte el bloque de encabezado + línea de
#        guiones, el bloque entero pasa a la página siguiente.
# 1.4.0  Portada por BOM: Item Selection 'Specific', Item y Revision propios.

# ── CONFIGURACIÓN ───────────────────────────────────────────────────────────
CARPETA_ENTRADA = "Input_PDFs"       # reportes consolidados
CARPETA_SALIDA  = "Split_Output"     # un PDF por BOM
RESUMEN_XLSX    = "Split_Resumen.xlsx"

MARGEN_INFERIOR = 26.0    # margen útil al pie de página
SEPARACION      = 12.0    # espacio entre la portada y el contenido del BOM
# ────────────────────────────────────────────────────────────────────────────

# Códigos Oracle: 2-4 caracteres, guion, y el resto (CE-82-061Z-A, 4D-81-584Z-G,
# DWG-SA-004194-D, BOM-011538...)
ITEM_RE    = re.compile(r"\bItem:\s*([A-Z0-9]{2,4}-[A-Z0-9-]{4,})", re.I)
ORG_RE     = re.compile(r"\bOrganization:", re.I)
EOR_RE     = re.compile(r"End of Report", re.I)
REV_RE     = re.compile(r"Revision:\s*([A-Z0-9]{1,4})\b", re.I)
FROM_TO_RE = re.compile(r"^(Item From:|To:)", re.I)
ITEM_LABEL_RE = re.compile(r"^Item:\s*$", re.I)
NOMBRE_MAL = re.compile(r'[<>:"/\\|?*]')


def nombre_seguro(valor):
    return NOMBRE_MAL.sub("_", str(valor).strip()).rstrip(". ") or "SIN_ITEM"


def _spans(page):
    for b in page.get_text("dict")["blocks"]:
        if b["type"] != 0:
            continue
        for line in b["lines"]:
            for s in line["spans"]:
                yield s


def lineas(page):
    """Devuelve [(y, texto, x0)] de la página, ordenado por y."""
    por_y = {}
    for s in _spans(page):
        por_y.setdefault(round(s["bbox"][1], 1), []).append(s)
    out = []
    for y in sorted(por_y):
        ss = sorted(por_y[y], key=lambda s: s["bbox"][0])
        out.append((y, "".join(s["text"] for s in ss),
                    min(s["bbox"][0] for s in ss)))
    return out


# ════════════════════════════════════════════════════════════════════════════
# LOCALIZAR LOS BOMs
# ════════════════════════════════════════════════════════════════════════════

def localizar_boms(doc):
    """Devuelve [{item, rev, pagina, y_inicio}] — uno por BOM.

    y_inicio es la línea 'Organization:' que precede al 'Item:'; si no la hay,
    se usa la propia línea del Item. `rev` es la revisión del part number, que
    Oracle imprime en la línea 'Alternate: … Revision: XXX' justo debajo.
    """
    encontrados = []
    for pn in range(len(doc)):
        ls = lineas(doc[pn])
        for i, (y, texto, _) in enumerate(ls):
            m = ITEM_RE.search(texto)
            if not m:
                continue
            # Buscar hacia atrás la línea 'Organization:' más cercana
            y_ini = y
            for j in range(i - 1, max(-1, i - 4), -1):
                if ORG_RE.search(ls[j][1]):
                    y_ini = ls[j][0]
                    break
            # La revisión del part number va en una de las líneas siguientes
            rev = None
            for j in range(i + 1, min(i + 4, len(ls))):
                mr = REV_RE.search(ls[j][1])
                if mr:
                    rev = mr.group(1).strip()
                    break

            encontrados.append({
                "item": m.group(1).upper().rstrip(".,;:"),
                "rev": rev,
                "pagina": pn,
                "y_inicio": y_ini,
            })

    # ── Quitar repeticiones del MISMO BOM ───────────────────────────────────
    # Cuando un BOM ocupa varias páginas, Oracle repite su encabezado (con el
    # mismo 'Item:') en cada una. Esas repeticiones NO son BOMs nuevos: se
    # descarta toda marca cuyo item sea igual al del BOM en curso.
    limpio = []
    for e in encontrados:
        if limpio and e["item"] == limpio[-1]["item"]:
            continue
        limpio.append(e)

    # Un mismo item podría reaparecer más adelante separado por otros BOMs
    # (poco habitual, pero entonces son entradas distintas del reporte). Se
    # avisa para que se pueda revisar.
    from collections import Counter
    repetidos = [it for it, n in Counter(e["item"] for e in limpio).items() if n > 1]
    if repetidos:
        print(f"   Aviso: {len(repetidos)} item(s) aparecen en bloques separados "
              f"del reporte: {', '.join(repetidos[:5])}"
              + (" ..." if len(repetidos) > 5 else ""))
    return limpio


def fin_del_reporte(doc):
    """(pagina, y) del 'End of Report' final."""
    for pn in range(len(doc) - 1, -1, -1):
        for y, texto, _ in lineas(doc[pn]):
            if EOR_RE.search(texto):
                return pn, y
    return len(doc) - 1, doc[len(doc) - 1].rect.height - MARGEN_INFERIOR


def limites(boms, doc):
    """Añade a cada BOM dónde termina: (pagina_fin, y_fin) = inicio del siguiente."""
    pn_eor, y_eor = fin_del_reporte(doc)
    for i, b in enumerate(boms):
        if i + 1 < len(boms):
            sig = boms[i + 1]
            b["pagina_fin"] = sig["pagina"]
            b["y_fin"] = sig["y_inicio"]
        else:
            b["pagina_fin"] = pn_eor
            b["y_fin"] = y_eor + 14      # incluir la línea del End of Report
    return boms


# ════════════════════════════════════════════════════════════════════════════
# CONSTRUIR EL PDF DE CADA BOM
# ════════════════════════════════════════════════════════════════════════════

def alto_portada(doc):
    """Hasta dónde llega el bloque de parámetros de la portada (pág. 1)."""
    ls = lineas(doc[0])
    ultimo = 0
    for y, texto, _ in ls:
        if ITEM_RE.search(texto) or ORG_RE.search(texto):
            break
        if texto.strip():
            ultimo = y
    return ultimo + 16


_CACHE_FONT = {}

# Fuentes monoespaciadas con las que escribir texto NUEVO. El Consolas del
# sistema (Windows) coincide exactamente con el del reporte; las demás son
# respaldos y su tamaño se ajusta para igualar el ancho de carácter del PDF.
_FUENTES = [
    r"C:/Windows/Fonts/consola.ttf",
    r"C:/Windows/Fonts/Consolas.ttf",
    "/Library/Fonts/Consolas.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
]


def fuente_del_pdf(doc):
    """Devuelve (fuente, tam) para escribir texto que se vea como el del PDF.

    NO se usa el tipo embebido del reporte: es un subset sin tabla ToUnicode,
    así que el texto escrito con él se ve bien pero NO se puede volver a leer
    (y el procesador de redline necesita leerlo). Se usa una fuente del sistema
    y se ajusta el tamaño para que el ancho de carácter coincida con el real
    del documento, de modo que el texto caiga alineado con sus columnas.
    """
    clave = id(doc)
    if clave in _CACHE_FONT:
        return _CACHE_FONT[clave]

    # Ancho de carácter real del reporte, medido de su línea de guiones
    char_w_pdf, tam_pdf = None, 9.75
    for pn in range(min(3, len(doc))):
        for y, texto, x0 in lineas(doc[pn]):
            if texto.count("-") >= 9 and re.search(r"-{5,}", texto):
                ancho_total = _ancho_linea(doc[pn], y)
                largo = len(texto.rstrip())
                if largo:
                    char_w_pdf = ancho_total / largo
                break
        if char_w_pdf:
            break
    for s_ in _spans(doc[0]):
        if s_["text"].strip() and s_["size"] > 5:
            tam_pdf = round(s_["size"], 2)
            break

    fuente = None
    for ruta in _FUENTES:
        if os.path.exists(ruta):
            try:
                fuente = fitz.Font(fontfile=ruta)
                break
            except Exception:
                continue
    if fuente is None:
        fuente = fitz.Font("cour")

    # Ajustar el tamaño para igualar el ancho de carácter del documento
    tam = tam_pdf
    if char_w_pdf:
        char_w_fuente = fuente.text_length("M", fontsize=tam_pdf)
        if char_w_fuente > 0:
            tam = round(tam_pdf * char_w_pdf / char_w_fuente, 2)

    _CACHE_FONT[clave] = (fuente, tam)
    return _CACHE_FONT[clave]


def _ancho_linea(page, y):
    """Ancho total (x1-x0) de la línea que empieza en esa y."""
    xs = [s["bbox"] for s in _spans(page) if abs(s["bbox"][1] - y) < 0.6]
    if not xs:
        return 0.0
    return max(b[2] for b in xs) - min(b[0] for b in xs)


def escribir_txt(pagina, x, y_base, texto, fuente, tam=9.75, color=(0, 0, 0)):
    """Escribe texto con TextWriter (queda extraíble y bien formado)."""
    if not texto or not str(texto).strip():
        return
    tw = fitz.TextWriter(pagina.rect, color=color)
    tw.append(fitz.Point(x, y_base), str(texto), font=fuente, fontsize=tam)
    tw.write_text(pagina)


def ajustar_portada(pagina, item, rev, fuente, tam):
    """Personaliza la portada copiada para este BOM:
      - Borra el VALOR de 'Item From:' y 'To:' (son los extremos del rango con
        el que se descargó el reporte; no aplican a un BOM concreto).
      - Escribe el part number de ESTE BOM junto a la etiqueta 'Item:'.
      - Cambia 'Item Selection: Range' por 'Specific': el reporte se descargó
        por rango, pero cada PDF separado corresponde a un item concreto.
      - Escribe la revisión del part number en la etiqueta 'Revision:'.

    Se trabaja con las palabras reales de la página (no con posiciones
    estimadas) para no recortar las etiquetas ni las líneas vecinas.
    """
    palabras = pagina.get_text("words")       # (x0, y0, x1, y1, texto, ...)

    # Agrupar por renglón
    por_y = {}
    for w in palabras:
        por_y.setdefault(round(w[1], 1), []).append(w)

    borrar = []       # rectángulos a limpiar
    escribir = []     # (x, y, texto) a insertar después (lista)

    for y in sorted(por_y):
        fila = sorted(por_y[y], key=lambda w: w[0])
        textos = [w[4] for w in fila]
        if not textos:
            continue
        primero = textos[0].strip().lower()

        # ── 'Item From:' / 'To:'  ->  borrar solo el valor ──────────────────
        es_item_from = (primero == "item" and len(textos) > 1
                        and textos[1].strip().lower().startswith("from"))
        es_to = primero == "to:"
        if es_item_from or es_to:
            # El valor son las palabras que siguen a la etiqueta (la que
            # termina en ':')
            idx_label = next((i for i, t in enumerate(textos) if t.endswith(":")), 0)
            valores = fila[idx_label + 1:]
            if valores:
                x_ini = min(w[0] for w in valores) - 1
                y0 = min(w[1] for w in valores)
                y1 = max(w[3] for w in valores)
                borrar.append(fitz.Rect(x_ini, y0, pagina.rect.width, y1))
            continue

        # ── 'Item Selection: Range'  ->  'Specific' ─────────────────────────
        es_item_selection = (primero == "item" and len(textos) > 1
                             and textos[1].strip().lower().startswith("selection"))
        if es_item_selection:
            idx_label = next((i for i, t in enumerate(textos) if t.endswith(":")), 0)
            valores = fila[idx_label + 1:]
            if valores:
                x_ini = min(w[0] for w in valores)
                y0 = min(w[1] for w in valores)
                y1 = max(w[3] for w in valores)
                borrar.append(fitz.Rect(x_ini - 1, y0, pagina.rect.width, y1))
                escribir.append((x_ini, y0 + tam * 0.85, "Specific"))
            continue

        # ── 'Revision:' sin valor  ->  la revisión de ESTE part number ──────
        if primero == "revision:" and rev:
            w0 = fila[0]
            if len(textos) == 1:                     # etiqueta sin valor
                escribir.append((w0[2] + tam * 0.6, w0[1] + tam * 0.85, rev))
            else:                                    # trae un valor: se sustituye
                valores = fila[1:]
                x_ini = min(w[0] for w in valores)
                y0 = min(w[1] for w in valores)
                y1 = max(w[3] for w in valores)
                borrar.append(fitz.Rect(x_ini - 1, y0, pagina.rect.width, y1))
                escribir.append((x_ini, y0 + tam * 0.85, rev))
            continue

        # ── 'Item:' sin valor  ->  poner el part number de este BOM ─────────
        if primero == "item:" and len(textos) == 1:
            w0 = fila[0]
            escribir.append((w0[2] + tam * 0.6, w0[1] + tam * 0.85, item))

    for r in borrar:
        pagina.add_redact_annot(r, fill=(1, 1, 1))
    if borrar:
        pagina.apply_redactions()
    for x, y, txt in escribir:
        escribir_txt(pagina, x, y, txt, fuente, tam)


DASHES_RE = re.compile(r"^[\s-]*-{5,}[\s-]*$")


def _franjas_de_texto(page):
    """[(y0, y1)] de cada renglón con texto, ordenado. Sirve para no cortar
    una línea por la mitad al paginar."""
    out = []
    for b in page.get_text("dict")["blocks"]:
        if b["type"] != 0:
            continue
        for ln in b["lines"]:
            if "".join(s["text"] for s in ln["spans"]).strip():
                out.append((ln["bbox"][1], ln["bbox"][3]))
    return sorted(out)


def _bloques_unidos(page):
    """Rangos (y0, y1) que NO se pueden partir entre dos páginas.

    El encabezado de la tabla ocupa varios renglones ('Op  Item' arriba y
    'Seq Seq' debajo) y termina en la línea de guiones. Si el corte cae en
    medio, una página queda con 'Item' y la siguiente empieza con 'Seq'.
    Aquí se agrupan esos renglones con su línea de guiones para moverlos
    juntos.
    """
    franjas = _franjas_de_texto(page)
    if len(franjas) < 2:
        return []

    tops = sorted({round(y0, 1) for y0, _y1 in franjas})
    fondo = {round(y0, 1): y1 for y0, y1 in franjas}
    saltos = [b - a for a, b in zip(tops, tops[1:])]
    paso = min(saltos) if saltos else 11.0        # separación entre renglones

    bloques = []
    for y, texto, _x in lineas(page):
        if not DASHES_RE.match(texto.strip()):
            continue
        clave = round(y, 1)
        if clave not in fondo:
            continue
        i = tops.index(clave)
        # Como mucho los DOS renglones de encima: el encabezado de Oracle hace
        # wrap en dos líneas ('Op  Item' / 'Seq Seq'). Más arriba ya es otra
        # cosa (Organization, Item:...) y no hay que arrastrarla.
        j = i
        for _ in range(2):
            if j == 0 or tops[j] - tops[j - 1] > paso * 1.6:
                break
            j -= 1
        bloques.append((tops[j], fondo[clave]))
    return bloques


def corte_seguro(page, desde, limite, minimo):
    """Y donde se puede cortar la página sin partir un renglón ni separar el
    encabezado de su tabla. Devuelve None si no hay ningún punto válido."""
    franjas = _franjas_de_texto(page)
    if not franjas:
        return limite

    # Los únicos puntos de corte limpios son los INICIOS de renglón: así las
    # líneas completas quedan arriba y ninguna se parte por la mitad. (Las
    # cajas de texto se solapan ~1 pt entre renglones, por eso no sirve buscar
    # un hueco vacío.)
    tops = sorted({y0 for y0, _y1 in franjas})
    candidatos = [t for t in tops if t <= limite + 0.5]
    if not candidatos:
        return None
    corte = max(candidatos)

    # Si ese punto parte el encabezado de su tabla, se sube al inicio del bloque.
    for b0, b1 in _bloques_unidos(page):
        if b0 < corte < b1:
            corte = b0
            break

    corte -= 1.0                     # 1 pt de aire para no rozar la línea de abajo
    if corte <= desde + minimo:
        return None
    return corte


def construir_bom(doc, bom, portada_h):
    """Arma el PDF de un BOM: portada + su contenido."""
    w = doc[0].rect.width
    h = doc[0].rect.height
    salida = fitz.open()

    # ── Página 1: portada + inicio del contenido ────────────────────────────
    pagina = salida.new_page(width=w, height=h)
    pagina.show_pdf_page(fitz.Rect(0, 0, w, portada_h), doc, 0,
                         clip=fitz.Rect(0, 0, w, portada_h))
    fuente, tam_fuente = fuente_del_pdf(doc)
    ajustar_portada(pagina, bom["item"], bom.get("rev"), fuente, tam_fuente)

    y_cursor = portada_h + SEPARACION
    pn, y = bom["pagina"], bom["y_inicio"]
    pn_fin, y_fin = bom["pagina_fin"], bom["y_fin"]

    while pn <= pn_fin:
        desde = y if pn == bom["pagina"] else 0
        hasta = y_fin if pn == pn_fin else h - MARGEN_INFERIOR
        alto = hasta - desde
        if alto <= 2:
            pn += 1
            continue

        disponible = (h - MARGEN_INFERIOR) - y_cursor
        if alto > disponible:
            # El corte NO se hace a ras del espacio disponible: se sube hasta
            # un punto donde no se parta un renglón ni se separe el encabezado
            # de su tabla ('Item' en una página y 'Seq' en la siguiente).
            corte = corte_seguro(doc[pn], desde, desde + disponible, 24)
            if corte is not None:
                trozo = corte - desde
                pagina.show_pdf_page(
                    fitz.Rect(0, y_cursor, w, y_cursor + trozo), doc, pn,
                    clip=fitz.Rect(0, desde, w, desde + trozo))
                desde = corte
                alto -= trozo
            pagina = salida.new_page(width=w, height=h)
            y_cursor = MARGEN_INFERIOR
            # Puede necesitar varias páginas más
            while alto > (h - MARGEN_INFERIOR * 2):
                tope = h - MARGEN_INFERIOR * 2
                corte = corte_seguro(doc[pn], desde, desde + tope, 24)
                trozo = (corte - desde) if corte is not None else tope
                pagina.show_pdf_page(
                    fitz.Rect(0, y_cursor, w, y_cursor + trozo), doc, pn,
                    clip=fitz.Rect(0, desde, w, desde + trozo))
                desde += trozo
                alto -= trozo
                pagina = salida.new_page(width=w, height=h)
                y_cursor = MARGEN_INFERIOR

        if alto > 2:
            pagina.show_pdf_page(
                fitz.Rect(0, y_cursor, w, y_cursor + alto), doc, pn,
                clip=fitz.Rect(0, desde, w, desde + alto))
            y_cursor += alto

        pn += 1
        y = 0

    # ── 'End of Report' propio ──────────────────────────────────────────────
    # Cada BOM separado debe cerrar con su propio marcador: es lo que delimita
    # la sección del BOM para las herramientas que lo procesan después.
    texto_eor = "***** End of Report *****"
    ya_tiene = any(EOR_RE.search(t) for _, t, _ in lineas(pagina))
    if not ya_tiene:
        if y_cursor > h - MARGEN_INFERIOR - 30:
            pagina = salida.new_page(width=w, height=h)
            y_cursor = MARGEN_INFERIOR
        ancho = fuente.text_length(texto_eor, fontsize=tam_fuente)
        escribir_txt(pagina, (w - ancho) / 2, y_cursor + 24 + tam_fuente * 0.85,
                     texto_eor, fuente, tam_fuente)

    return salida


# ════════════════════════════════════════════════════════════════════════════
# PROCESO
# ════════════════════════════════════════════════════════════════════════════

def procesar(pdf_path, carpeta_salida):
    doc = fitz.open(pdf_path)
    stem = Path(pdf_path).stem
    print(f"\n[{stem}]  {len(doc)} páginas")

    boms = limites(localizar_boms(doc), doc)
    print(f"   BOMs detectados: {len(boms)}")
    if not boms:
        print("   *** No se encontró ningún 'Item:' — revisa el formato ***")
        return []

    portada_h = alto_portada(doc)
    carpeta_salida.mkdir(parents=True, exist_ok=True)

    filas = []
    for i, b in enumerate(boms, 1):
        nombre = nombre_seguro(b["item"]) + ".pdf"
        destino = carpeta_salida / nombre
        n = 2
        while destino.exists():
            destino = carpeta_salida / f"{nombre_seguro(b['item'])}({n}).pdf"
            n += 1
        try:
            out = construir_bom(doc, b, portada_h)
            out.save(str(destino))
            out.close()
            filas.append({"item": b["item"], "archivo": destino.name,
                          "origen": stem, "pagina": b["pagina"] + 1,
                          "paginas_salida": "", "estado": "OK"})
            if i <= 5 or i % 25 == 0:
                print(f"   [{i:3d}/{len(boms)}] {b['item']} -> {destino.name}")
        except Exception as e:
            filas.append({"item": b["item"], "archivo": "", "origen": stem,
                          "pagina": b["pagina"] + 1, "paginas_salida": "",
                          "estado": f"ERROR: {e!r}"})
            print(f"   [{i:3d}] ERROR en {b['item']}: {e!r}")

    doc.close()
    return filas


def crear_resumen(filas, ruta):
    wb = Workbook(); ws = wb.active; ws.title = "Resumen"
    hdr = ["item", "archivo", "origen", "pagina_en_reporte", "estado"]
    fill = PatternFill("solid", fgColor="1F4E78")
    fnt = Font(name="Arial", bold=True, color="FFFFFF", size=10)
    thin = Side(style="thin", color="D0D0D0")
    bd = Border(left=thin, right=thin, top=thin, bottom=thin)
    for j, h in enumerate(hdr, 1):
        c = ws.cell(1, j, h); c.fill = fill; c.font = fnt; c.border = bd
        c.alignment = Alignment(horizontal="center")
    for i, f in enumerate(filas, 2):
        for j, k in enumerate(["item", "archivo", "origen", "pagina", "estado"], 1):
            ws.cell(i, j, f.get(k, "")).border = bd
    for col, w in zip("ABCDE", [22, 34, 30, 18, 40]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    wb.save(str(ruta))


def main():
    base = Path(__file__).parent
    entrada = base / CARPETA_ENTRADA
    salida = base / CARPETA_SALIDA

    print("=" * 62)
    print(f" Splitter de BOMs v{__version__}")
    print("=" * 62)

    if not entrada.exists():
        entrada.mkdir(parents=True, exist_ok=True)
        print(f"Se creó la carpeta '{CARPETA_ENTRADA}'. Pon ahí los reportes.")
        return

    # En Windows el sistema de archivos no distingue mayúsculas, así que
    # buscar "*.pdf" y "*.PDF" por separado devolvería CADA archivo DOS VECES.
    # Se deduplica por ruta absoluta en minúsculas.
    vistos, pdfs = set(), []
    for f in sorted(list(entrada.glob("*.pdf")) + list(entrada.glob("*.PDF"))):
        clave = str(f.resolve()).lower()
        if clave not in vistos:
            vistos.add(clave)
            pdfs.append(f)
    if not pdfs:
        print(f"No hay PDFs en '{CARPETA_ENTRADA}'.")
        return

    todas = []
    for p in pdfs:
        todas.extend(procesar(p, salida))

    crear_resumen(todas, base / RESUMEN_XLSX)
    ok = sum(1 for f in todas if f["estado"] == "OK")
    print("\n" + "=" * 62)
    print(f" BOMs separados OK : {ok}")
    print(f" Con error         : {len(todas) - ok}")
    print(f" Carpeta de salida : {salida}")
    print(f" Resumen           : {RESUMEN_XLSX}")
    print("=" * 62)


if __name__ == "__main__":
    main()
