"""
bom_marcar.py — MARCADOR de BOMs (v1.0.0, 2026-10-13)

Hermano del redline, pero SIN TACHADOS: solo pone en ROJO y SUBRAYA lo que le
indiques de un BOM, y si le das un valor nuevo lo escribe en rojo en el lugar
del viejo (el viejo se borra, no se tacha).

Para qué sirve:
  · resaltar componentes completos que quieres que salten a la vista
  · resaltar un solo dato de un componente (su Rev, su cantidad, su Item Seq...)
  · cambiar números de Item Seq / Op Seq / Level o la Rev de un componente,
    dejando el valor nuevo en rojo subrayado

Se apoya en bom_layout.py y bom_engine.py (deben estar en la misma carpeta).

CÓMO SE USA
-----------
1. Pon los PDFs en la carpeta de entrada (abajo, CARPETA_ENTRADA).
2. Llena el Excel de marcas (ARCHIVO_EXCEL). Si no existe, córrelo una vez y
   te crea una plantilla con el formato correcto.
3. python bom_marcar.py
   Salida: <nombre>_MARCADO.pdf en la carpeta de salida.

EL EXCEL — una sola hoja llamada "Marcas", con estas columnas:

  nombre_archivo | item          | campo    | valor_nuevo
  ---------------+---------------+----------+------------
  4D-81-584Z-G   | 4D-17-054Z-X  |          |              -> marca la fila entera
  4D-81-584Z-G   | 4D-82-584Z-G  | rev      |              -> marca solo la Rev
  4D-81-584Z-G   | 4D-87-775Z-B  | item_seq | 45           -> cambia a 45, en rojo
  4D-81-584Z-G   | 4D-87-949Z-A  | cantidad | 7.00         -> cambia la cantidad

  · nombre_archivo: basta con que el nombre del PDF lo CONTENGA.
  · item: el part number tal como aparece en la columna Item.
  · campo: vacío = fila completa. Si no: level/nivel, op_seq, item_seq, item,
    descripcion, rev, uom, cantidad, status, category.
  · valor_nuevo: vacío = solo marcar. Con valor = reemplazar y marcar.
"""

import os
import re
import sys

import fitz

from bom_layout import detect_layout, validate_layout
import bom_engine as eng

__version__ = "1.0.0"
__fecha__ = "2026-10-13"

# ── Historial ───────────────────────────────────────────────────────────────
# 1.0.0  Primera versión: marcado en rojo + subrayado de filas y de campos
#        sueltos, con reemplazo opcional del valor (sin tachar el anterior).

# ════════════════════════════════════════════════════════════════════════════
# CONFIGURACIÓN
# ════════════════════════════════════════════════════════════════════════════

CARPETA_ENTRADA = "entrada"
CARPETA_SALIDA = "salida_marcado"
ARCHIVO_EXCEL = "Marcas.xlsx"
SUFIJO_SALIDA = "_MARCADO"

# Grosor del subrayado, en puntos.
GROSOR_SUBRAYADO = 0.7

ROJO = eng.RED
BLANCO = eng.WHITE


# ════════════════════════════════════════════════════════════════════════════
# MARCADO
# ════════════════════════════════════════════════════════════════════════════

def _palabras_de_la_fila(page, layout, iy0, x_desde=None, x_hasta=None):
    """Palabras que están en la misma fila (misma Y) que el componente."""
    tol = eng._tol_y(layout)
    out = []
    for x0, y0, x1, y1, t, *_ in page.get_text("words"):
        if abs(y0 - iy0) >= tol:
            continue
        if x_desde is not None and x0 < x_desde - 1:
            continue
        if x_hasta is not None and x0 >= x_hasta:
            continue
        if t.strip():
            out.append((x0, y0, x1, y1, t))
    return sorted(out, key=lambda w: w[0])


def _repintar(page, layout, palabras, font_path=None, font_obj=None):
    """Borra las palabras y las vuelve a escribir en rojo, en su mismo sitio.
    Devuelve (x_inicio, x_fin, y_arriba, y_abajo) del conjunto."""
    sz = eng._fontsize_ajustado(layout, layout["font_size"])

    for x0, y0, x1, y1, _t in palabras:
        page.add_redact_annot(fitz.Rect(x0 - 0.5, y0 + 0.3, x1 + 0.5, y1 - 0.3),
                              fill=BLANCO)
    page.apply_redactions()

    for x0, y0, x1, y1, t in palabras:
        eng._write(page, x0, y0 + sz * 0.85, t, sz, ROJO, font_path, font_obj)

    vx0 = min(w[0] for w in palabras)
    vx1 = max(w[2] for w in palabras)
    vy0 = min(w[1] for w in palabras)
    vy1 = max(w[3] for w in palabras)
    return vx0, vx1, vy0, vy1


def _subrayar(page, x0, x1, y_base):
    page.draw_line(fitz.Point(x0, y_base), fitz.Point(x1, y_base),
                   color=ROJO, width=GROSOR_SUBRAYADO)


def marcar_fila(doc, layout, item, font_path=None, font_obj=None):
    """Pone en rojo y subraya la FILA COMPLETA del componente `item`."""
    occ = eng.find_in_bom_section(doc, layout, item)
    if not occ:
        return False, f"Componente '{item}' no encontrado en la sección del BOM."

    pn, _ix0, iy0, _ix1, _iy1 = occ[0]
    page = doc[pn]

    # Solo lo que está dentro de la tabla: desde la primera columna hasta el
    # final de la última. Así no se repinta nada del encabezado ni del margen.
    cols = eng._ordered_columns(layout)
    x_desde = cols[0][1] - layout["char_w"]
    ult, x_ult = cols[-1]
    x_hasta = x_ult + (layout["col_w"].get(ult, 12) + 2) * layout["char_w"]

    palabras = _palabras_de_la_fila(page, layout, iy0, x_desde, x_hasta)
    if not palabras:
        return False, f"'{item}': no se encontró texto en su fila."

    vx0, vx1, vy0, vy1 = _repintar(page, layout, palabras, font_path, font_obj)
    _subrayar(page, vx0, vx1, vy1 - 0.3)
    return True, f"'{item}': fila marcada en rojo (pág. {pn + 1})."


def marcar_campo(doc, layout, item, campo, valor_nuevo=None,
                 font_path=None, font_obj=None):
    """Marca un solo campo del componente. Si `valor_nuevo` tiene contenido,
    sustituye el valor (el anterior se borra, NO se tacha)."""
    key = eng.FIELD_ALIASES.get(str(campo).strip().lower())
    if key is None or key not in layout["col_x"]:
        return False, f"Campo '{campo}' no reconocido o ausente en este formato."

    occ = eng.find_in_bom_section(doc, layout, item)
    if not occ:
        return False, f"Componente '{item}' no encontrado en la sección del BOM."

    pn, _ix0, iy0, _ix1, _iy1 = occ[0]
    page = doc[pn]
    sz = eng._fontsize_ajustado(layout, layout["font_size"])

    fx0, fx1 = eng._col_bounds(layout, key)
    palabras = _palabras_de_la_fila(page, layout, iy0, fx0, fx1)
    if not palabras:
        return False, f"'{item}': no se encontró el valor de '{campo}'."

    anterior = " ".join(w[4] for w in palabras)

    # ── Solo marcar ────────────────────────────────────────────────────────
    if valor_nuevo is None or str(valor_nuevo).strip() == "":
        vx0, vx1, vy0, vy1 = _repintar(page, layout, palabras, font_path, font_obj)
        _subrayar(page, vx0, vx1, vy1 - 0.3)
        return True, f"'{item}': {campo} '{anterior}' marcado (pág. {pn + 1})."

    # ── Reemplazar y marcar ────────────────────────────────────────────────
    nuevo = str(valor_nuevo).strip()
    vx0 = min(w[0] for w in palabras)
    vx1 = max(w[2] for w in palabras)
    vy0 = min(w[1] for w in palabras)
    vy1 = max(w[3] for w in palabras)

    page.add_redact_annot(fitz.Rect(vx0 - 0.5, vy0 + 0.3, vx1 + 0.5, vy1 - 0.3),
                          fill=BLANCO)
    page.apply_redactions()

    ancho = eng._text_width(nuevo, sz)
    if key == "qty":
        # La cantidad va alineada a la derecha, como en el reporte original.
        derecha = (layout["col_x"]["qty"]
                   + layout["col_w"].get("qty", 9) * layout["char_w"])
        nx = derecha - ancho
    else:
        nx = vx0
        # Si el valor nuevo es más largo que la columna, se recorta el avance
        # para no invadir la columna siguiente.
        if fx1 and nx + ancho > fx1:
            nx = max(fx0, fx1 - ancho)

    eng._write(page, nx, vy0 + sz * 0.85, nuevo, sz, ROJO, font_path, font_obj)
    _subrayar(page, nx, nx + ancho, vy1 - 0.3)
    return True, f"'{item}': {campo} '{anterior}' → '{nuevo}' en rojo (pág. {pn + 1})."


# ════════════════════════════════════════════════════════════════════════════
# EXCEL
# ════════════════════════════════════════════════════════════════════════════

COLUMNAS = ["nombre_archivo", "item", "campo", "valor_nuevo"]


def _limpio(v):
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.lower() in ("none", "nan") else s


def crear_plantilla(ruta):
    """Crea un Excel vacío con el formato correcto y un par de ejemplos."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = "Marcas"
    ws.append(["Deja 'campo' vacío para marcar la fila completa. "
               "Deja 'valor_nuevo' vacío para solo marcar, sin cambiar nada."])
    ws.append(COLUMNAS)
    ws.append(["4D-81-584Z-G", "4D-17-054Z-X", "", ""])
    ws.append(["4D-81-584Z-G", "4D-87-775Z-B", "item_seq", "45"])

    ws["A1"].font = Font(italic=True, color="666666")
    for c in ws[2]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="4F6228")
    for col, ancho in zip("ABCD", (22, 20, 14, 14)):
        ws.column_dimensions[col].width = ancho

    wb.save(ruta)


def leer_marcas(ruta):
    """Devuelve {clave_de_archivo: [(item, campo, valor_nuevo), ...]}."""
    from openpyxl import load_workbook

    wb = load_workbook(ruta, data_only=True)
    ws = wb["Marcas"] if "Marcas" in wb.sheetnames else wb[wb.sheetnames[0]]

    # El encabezado puede no estar en la fila 1 (suele haber una nota arriba).
    filas = list(ws.iter_rows(values_only=True))
    hdr_i, col = None, {}
    for i, fila in enumerate(filas):
        valores = [_limpio(v).lower() for v in fila]
        if "nombre_archivo" in valores and "item" in valores:
            hdr_i = i
            col = {v: j for j, v in enumerate(valores) if v}
            break
    if hdr_i is None:
        raise ValueError("El Excel no tiene una fila de encabezado con "
                         "'nombre_archivo' e 'item'.")

    marcas = {}
    for fila in filas[hdr_i + 1:]:
        if not any(fila):
            continue
        naf = _limpio(fila[col["nombre_archivo"]]) if "nombre_archivo" in col else ""
        item = _limpio(fila[col["item"]]) if "item" in col else ""
        campo = _limpio(fila[col["campo"]]) if "campo" in col else ""
        valor = _limpio(fila[col["valor_nuevo"]]) if "valor_nuevo" in col else ""
        if naf and item:
            marcas.setdefault(naf, []).append((item, campo, valor))
    return marcas


# ════════════════════════════════════════════════════════════════════════════
# MOTOR
# ════════════════════════════════════════════════════════════════════════════

def _pdfs_de(carpeta):
    """PDFs de la carpeta, sin duplicados (en Windows *.pdf y *.PDF repiten)."""
    vistos, out = set(), []
    for n in sorted(os.listdir(carpeta)):
        if not n.lower().endswith(".pdf"):
            continue
        clave = os.path.normcase(os.path.abspath(os.path.join(carpeta, n)))
        if clave in vistos:
            continue
        vistos.add(clave)
        out.append(os.path.join(carpeta, n))
    return out


def _marcas_del_pdf(stem, marcas):
    """La clave del Excel basta con que esté CONTENIDA en el nombre del PDF."""
    s = stem.lower()
    acumulado = []
    for clave, lista in marcas.items():
        k = clave.lower()
        if k == s or k in s or s in k:
            acumulado.extend(lista)
    return acumulado


def procesar_uno(ruta_pdf, lista, carpeta_salida):
    lineas = []
    doc = fitz.open(ruta_pdf)
    layout = detect_layout(doc)
    ok, msg = validate_layout(doc, layout)
    if not ok:
        doc.close()
        return False, [f"   · layout: {msg}"], None

    lineas.append(f"   · layout: {msg}")

    hechas = 0
    for item, campo, valor in lista:
        if campo:
            r, m = marcar_campo(doc, layout, item, campo, valor)
        else:
            r, m = marcar_fila(doc, layout, item)
        lineas.append(("   · " if r else "   ! ") + m)
        hechas += 1 if r else 0
        layout = detect_layout(doc)       # las redacciones mueven referencias

    stem = os.path.splitext(os.path.basename(ruta_pdf))[0]
    salida = os.path.join(carpeta_salida, f"{stem}{SUFIJO_SALIDA}.pdf")
    doc.save(salida, garbage=3, deflate=True)
    doc.close()
    return hechas > 0, lineas, salida


def run_batch(carpeta_entrada=CARPETA_ENTRADA, excel=ARCHIVO_EXCEL,
              carpeta_salida=CARPETA_SALIDA):
    """Procesa la carpeta entera. Devuelve una lista de líneas para imprimir."""
    out = [f"Marcador de BOMs v{__version__} ({__fecha__})"]

    if not os.path.isdir(carpeta_entrada):
        return out + [f"No existe la carpeta de entrada '{carpeta_entrada}'."]

    if not os.path.exists(excel):
        crear_plantilla(excel)
        return out + [f"No había Excel de marcas: creé la plantilla '{excel}'.",
                      "Llénala y vuelve a correr el programa."]

    marcas = leer_marcas(excel)
    os.makedirs(carpeta_salida, exist_ok=True)
    pdfs = _pdfs_de(carpeta_entrada)
    out.append(f"PDFs en carpeta: {len(pdfs)} | Archivos en el Excel: {len(marcas)}")

    usados, ok_n, err_n = set(), 0, 0
    for ruta in pdfs:
        stem = os.path.splitext(os.path.basename(ruta))[0]
        lista = _marcas_del_pdf(stem, marcas)
        if not lista:
            out.append(f"\n[--] {stem}  (sin marcas en el Excel, se omite)")
            continue
        usados.update(k for k in marcas
                      if k.lower() in stem.lower() or stem.lower() in k.lower())
        try:
            ok, lineas, salida = procesar_uno(ruta, lista, carpeta_salida)
        except Exception as e:
            err_n += 1
            out.append(f"\n[ERROR] {stem}: {e}")
            continue
        etiqueta = "OK" if ok else "SIN CAMBIOS"
        out.append(f"\n[{etiqueta}] {stem}  ->  {os.path.basename(salida)}"
                   if salida else f"\n[{etiqueta}] {stem}")
        out.extend(lineas)
        ok_n += 1 if ok else 0

    sobran = [k for k in marcas if k not in usados]
    out.append("\n" + "=" * 58)
    out.append(f"Marcados OK : {ok_n}")
    out.append(f"Con error   : {err_n}")
    if sobran:
        out.append(f"En el Excel pero sin PDF: {', '.join(sobran)}")
    return out


if __name__ == "__main__":
    base = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base)
    for linea in run_batch():
        print(linea)
